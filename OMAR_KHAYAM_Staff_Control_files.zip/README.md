# OMAR KHAYAM | Staff Control

Telegram staff-management bot for one restaurant branch.

## Included in this starter version
- Employee self-registration
- Attendance clock-in and clock-out with Telegram location and photo evidence
- Employee list for management
- Tasks assigned by management and employee completion
- Basic daily report
- Employee shift schedule

## Environment variables
- `BOT_TOKEN` — Telegram bot token from BotFather. Never put it in GitHub.
- `DIRECTOR_IDS` — comma-separated Telegram numeric user IDs for director/management access.
- `TIMEZONE` — defaults to `Asia/Dushanbe`.
- `DB_PATH` — defaults to `omar_khayam.db`.

## Important deployment note
This version uses SQLite. The database file must live on persistent storage. If the hosting provider deletes local files on restart/redeploy, employee and attendance data may be lost. For production, migrate to managed PostgreSQL with persistent backups.

## First setup
1. Add `BOT_TOKEN` as a secret environment variable in the hosting provider.
2. Ask the director to message the bot with `/myid`.
3. Set `DIRECTOR_IDS` to that numeric ID in hosting environment variables, then restart the service.
4. Each employee starts the bot and uses `/register Name; Department; Position`.

This is an initial working MVP, not yet a complete HR/payroll or tamper-proof attendance system. GPS can be spoofed; photo and location are supporting evidence, not an absolute guarantee of physical presence.
