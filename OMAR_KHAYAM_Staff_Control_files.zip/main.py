import os
import logging
import sqlite3
from datetime import datetime, timezone
from zoneinfo import ZoneInfo

from telegram import (
    Update, KeyboardButton, ReplyKeyboardMarkup, ReplyKeyboardRemove,
    InlineKeyboardButton, InlineKeyboardMarkup
)
from telegram.ext import (
    Application, CommandHandler, MessageHandler, CallbackQueryHandler,
    ConversationHandler, ContextTypes, filters
)

# OMAR KHAYAM | Staff Control
# Required environment variables: BOT_TOKEN, DIRECTOR_IDS
# Optional: TIMEZONE (default Asia/Dushanbe), DB_PATH (default omar_khayam.db)

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO
)
log = logging.getLogger(__name__)

TOKEN = os.getenv("BOT_TOKEN", "").strip()
DIRECTOR_IDS = {
    int(x.strip()) for x in os.getenv("DIRECTOR_IDS", "").split(",")
    if x.strip().isdigit()
}
TZ = ZoneInfo(os.getenv("TIMEZONE", "Asia/Dushanbe"))
DB_PATH = os.getenv("DB_PATH", "omar_khayam.db")

WAIT_LOCATION, WAIT_PHOTO, WAIT_TASK, WAIT_TASK_EMPLOYEE, WAIT_SCHEDULE = range(5)


def now_local():
    return datetime.now(TZ)


def stamp():
    return now_local().isoformat(timespec="seconds")


def db():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con


def init_db():
    with db() as con:
        con.executescript("""
        CREATE TABLE IF NOT EXISTS employees (
            user_id INTEGER PRIMARY KEY,
            full_name TEXT NOT NULL,
            department TEXT NOT NULL,
            position TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'employee',
            active INTEGER NOT NULL DEFAULT 1,
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS attendance (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            action TEXT NOT NULL,
            created_at TEXT NOT NULL,
            latitude REAL,
            longitude REAL,
            photo_file_id TEXT
        );
        CREATE TABLE IF NOT EXISTS tasks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            assigned_to INTEGER NOT NULL,
            created_by INTEGER NOT NULL,
            status TEXT NOT NULL DEFAULT 'new',
            created_at TEXT NOT NULL,
            completed_at TEXT,
            proof_file_id TEXT
        );
        CREATE TABLE IF NOT EXISTS schedules (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            shift_date TEXT NOT NULL,
            start_time TEXT NOT NULL,
            end_time TEXT NOT NULL,
            note TEXT DEFAULT ''
        );
        """)
        # Existing director IDs are promoted automatically when they use the bot.
        for uid in DIRECTOR_IDS:
            con.execute("""
                INSERT INTO employees(user_id, full_name, department, position, role, created_at)
                VALUES (?, ?, 'Администрация', 'Директор', 'director', ?)
                ON CONFLICT(user_id) DO UPDATE SET role='director', active=1
            """, (uid, f"Директор {uid}", stamp()))


def is_director(uid):
    if uid in DIRECTOR_IDS:
        return True
    with db() as con:
        row = con.execute("SELECT role FROM employees WHERE user_id=?", (uid,)).fetchone()
        return bool(row and row["role"] in ("director", "manager", "admin"))


def is_registered(uid):
    with db() as con:
        return con.execute(
            "SELECT 1 FROM employees WHERE user_id=? AND active=1", (uid,)
        ).fetchone() is not None


def main_keyboard(uid):
    rows = [
        [KeyboardButton("🟢 Отметить приход"), KeyboardButton("🔴 Отметить уход")],
        [KeyboardButton("📋 Мои задания"), KeyboardButton("🕒 Мой график")],
        [KeyboardButton("🆔 Мой ID"), KeyboardButton("❓ Помощь")]
    ]
    if is_director(uid):
        rows += [
            [KeyboardButton("👥 Сотрудники"), KeyboardButton("📊 Отчёт")],
            [KeyboardButton("➕ Создать задание"), KeyboardButton("🗓 Установить график")]
        ]
    return ReplyKeyboardMarkup(rows, resize_keyboard=True)


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    if not is_registered(uid):
        await update.message.reply_text(
            "Добро пожаловать в OMAR KHAYAM | Staff Control.\n\n"
            "Чтобы зарегистрироваться, отправьте команду:\n"
            "/register Имя Фамилия; Отдел; Должность\n\n"
            "Пример:\n/register Али Каримов; Кухня; Повар\n\n"
            f"Ваш Telegram ID: {uid}\n"
            "Передайте этот ID директору для добавления в DIRECTOR_IDS при настройке."
        )
        return
    await update.message.reply_text(
        "Добро пожаловать! Выберите нужное действие в меню.",
        reply_markup=main_keyboard(uid)
    )


async def myid(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(f"Ваш Telegram ID: {update.effective_user.id}")


async def register(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    raw = " ".join(context.args).strip()
    parts = [p.strip() for p in raw.split(";")]
    if len(parts) != 3 or not all(parts):
        await update.message.reply_text(
            "Формат регистрации:\n/register Имя Фамилия; Отдел; Должность\n"
            "Пример:\n/register Али Каримов; Кухня; Повар"
        )
        return
    name, department, position = parts
    with db() as con:
        con.execute("""
            INSERT INTO employees(user_id, full_name, department, position, role, created_at)
            VALUES (?, ?, ?, ?, 'employee', ?)
            ON CONFLICT(user_id) DO UPDATE SET
                full_name=excluded.full_name, department=excluded.department,
                position=excluded.position, active=1
        """, (uid, name, department, position, stamp()))
    await update.message.reply_text(
        f"Заявка/регистрация сохранена: {name}, {department}, {position}.\n"
        "Если бот сообщает, что доступ ограничен, попросите администратора проверить регистрацию.",
        reply_markup=main_keyboard(uid)
    )


async def begin_attendance(update: Update, context: ContextTypes.DEFAULT_TYPE, action: str):
    uid = update.effective_user.id
    if not is_registered(uid):
        await update.message.reply_text("Сначала зарегистрируйтесь: /register Имя Фамилия; Отдел; Должность")
        return ConversationHandler.END
    context.user_data["attendance_action"] = action
    label = "прихода" if action == "in" else "ухода"
    kb = ReplyKeyboardMarkup(
        [[KeyboardButton("📍 Отправить геолокацию", request_location=True)],
         [KeyboardButton("Отмена")]],
        resize_keyboard=True, one_time_keyboard=True
    )
    await update.message.reply_text(
        f"Для отметки {label} отправьте геолокацию через кнопку ниже.",
        reply_markup=kb
    )
    return WAIT_LOCATION


async def clock_in_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    return await begin_attendance(update, context, "in")


async def clock_out_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    return await begin_attendance(update, context, "out")


async def location_received(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.message.text == "Отмена":
        await update.message.reply_text("Отменено.", reply_markup=main_keyboard(update.effective_user.id))
        return ConversationHandler.END
    loc = update.message.location
    if not loc:
        await update.message.reply_text("Пожалуйста, используйте кнопку «Отправить геолокацию».")
        return WAIT_LOCATION
    context.user_data["attendance_location"] = (loc.latitude, loc.longitude)
    await update.message.reply_text(
        "Геолокация получена. Теперь отправьте фотографию для подтверждения.",
        reply_markup=ReplyKeyboardRemove()
    )
    return WAIT_PHOTO


async def photo_received(update: Update, context: ContextTypes.DEFAULT_TYPE):
    photos = update.message.photo
    if not photos:
        await update.message.reply_text("Пожалуйста, отправьте фотографию.")
        return WAIT_PHOTO
    uid = update.effective_user.id
    lat, lon = context.user_data.get("attendance_location", (None, None))
    action = context.user_data.get("attendance_action", "in")
    photo_id = photos[-1].file_id
    with db() as con:
        con.execute(
            "INSERT INTO attendance(user_id, action, created_at, latitude, longitude, photo_file_id) VALUES (?, ?, ?, ?, ?, ?)",
            (uid, action, stamp(), lat, lon, photo_id)
        )
    label = "Приход" if action == "in" else "Уход"
    await update.message.reply_text(
        f"✅ {label} отмечен.\nВремя: {now_local().strftime('%d.%m.%Y %H:%M:%S')}\n"
        f"Геолокация: {lat:.5f}, {lon:.5f}",
        reply_markup=main_keyboard(uid)
    )
    context.user_data.clear()
    return ConversationHandler.END


async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data.clear()
    await update.message.reply_text("Действие отменено.", reply_markup=main_keyboard(update.effective_user.id))
    return ConversationHandler.END


async def employees(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_director(update.effective_user.id):
        await update.message.reply_text("Недостаточно прав.")
        return
    with db() as con:
        rows = con.execute(
            "SELECT user_id, full_name, department, position, role FROM employees WHERE active=1 ORDER BY department, full_name"
        ).fetchall()
    if not rows:
        await update.message.reply_text("Пока нет зарегистрированных сотрудников.")
        return
    lines = ["👥 Сотрудники:"]
    for r in rows:
        lines.append(f"• {r['full_name']} — {r['department']}, {r['position']} | ID {r['user_id']} | {r['role']}")
    await update.message.reply_text("\n".join(lines))


async def create_task(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_director(update.effective_user.id):
        await update.message.reply_text("Создавать задания может только руководство.")
        return ConversationHandler.END
    with db() as con:
        rows = con.execute("SELECT user_id, full_name FROM employees WHERE active=1 ORDER BY full_name").fetchall()
    if not rows:
        await update.message.reply_text("Сначала сотрудники должны зарегистрироваться.")
        return ConversationHandler.END
    buttons = [[InlineKeyboardButton(r["full_name"], callback_data=f"taskuser:{r['user_id']}")] for r in rows]
    await update.message.reply_text("Кому назначить задание?", reply_markup=InlineKeyboardMarkup(buttons))
    return WAIT_TASK_EMPLOYEE


async def choose_task_employee(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    uid = int(q.data.split(":")[1])
    context.user_data["task_assignee"] = uid
    await q.edit_message_text("Теперь отправьте текст задания одним сообщением.")
    return WAIT_TASK


async def save_task(update: Update, context: ContextTypes.DEFAULT_TYPE):
    title = update.message.text.strip()
    if not title:
        await update.message.reply_text("Текст задания не может быть пустым.")
        return WAIT_TASK
    assignee = context.user_data.get("task_assignee")
    with db() as con:
        cur = con.execute(
            "INSERT INTO tasks(title, assigned_to, created_by, created_at) VALUES (?, ?, ?, ?)",
            (title, assignee, update.effective_user.id, stamp())
        )
        task_id = cur.lastrowid
    try:
        await context.bot.send_message(assignee, f"📌 Новое задание №{task_id}:\n{title}\n\nКогда выполните, нажмите /done {task_id}")
    except Exception:
        pass
    await update.message.reply_text(f"Задание №{task_id} сохранено.")
    context.user_data.clear()
    return ConversationHandler.END


async def my_tasks(update: Update, context: ContextTypes.DEFAULT_TYPE):
    with db() as con:
        rows = con.execute(
            "SELECT id, title, status, created_at FROM tasks WHERE assigned_to=? ORDER BY id DESC LIMIT 20",
            (update.effective_user.id,)
        ).fetchall()
    if not rows:
        await update.message.reply_text("У вас пока нет заданий.")
        return
    lines = ["📋 Ваши задания:"]
    for r in rows:
        status = "Выполнено" if r["status"] == "done" else "В работе"
        lines.append(f"№{r['id']} [{status}] — {r['title']} ({r['created_at']})")
    await update.message.reply_text("\n".join(lines))


async def done(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args or not context.args[0].isdigit():
        await update.message.reply_text("Формат: /done номер_задания")
        return
    task_id = int(context.args[0])
    with db() as con:
        cur = con.execute(
            "UPDATE tasks SET status='done', completed_at=? WHERE id=? AND assigned_to=?",
            (stamp(), task_id, update.effective_user.id)
        )
    if cur.rowcount:
        await update.message.reply_text(f"✅ Задание №{task_id} отмечено выполненным.")
        for admin_id in DIRECTOR_IDS:
            try:
                await context.bot.send_message(admin_id, f"Сотрудник {update.effective_user.full_name} выполнил задание №{task_id}.")
            except Exception:
                pass
    else:
        await update.message.reply_text("Задание не найдено или оно назначено не вам.")


async def report(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_director(update.effective_user.id):
        await update.message.reply_text("Отчёт доступен только руководству.")
        return
    today = now_local().date().isoformat()
    with db() as con:
        people = con.execute("SELECT COUNT(*) n FROM employees WHERE active=1").fetchone()["n"]
        ins = con.execute(
            "SELECT COUNT(*) n FROM attendance WHERE action='in' AND substr(created_at,1,10)=?", (today,)
        ).fetchone()["n"]
        outs = con.execute(
            "SELECT COUNT(*) n FROM attendance WHERE action='out' AND substr(created_at,1,10)=?", (today,)
        ).fetchone()["n"]
        open_tasks = con.execute("SELECT COUNT(*) n FROM tasks WHERE status!='done'").fetchone()["n"]
        done_tasks = con.execute(
            "SELECT COUNT(*) n FROM tasks WHERE status='done' AND substr(completed_at,1,10)=?", (today,)
        ).fetchone()["n"]
    await update.message.reply_text(
        f"📊 ОТЧЁТ OMAR KHAYAM\nДата: {now_local().strftime('%d.%m.%Y')}\n\n"
        f"Активных сотрудников: {people}\n"
        f"Отметок прихода сегодня: {ins}\n"
        f"Отметок ухода сегодня: {outs}\n"
        f"Открытых заданий: {open_tasks}\n"
        f"Выполнено заданий сегодня: {done_tasks}"
    )


async def set_schedule(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_director(update.effective_user.id):
        await update.message.reply_text("Устанавливать график может только руководство.")
        return ConversationHandler.END
    if len(context.args) < 4:
        await update.message.reply_text(
            "Формат:\n/schedule Telegram_ID; ГГГГ-ММ-ДД; ЧЧ:ММ; ЧЧ:ММ; Примечание\n"
            "Пример:\n/schedule 123456789; 2026-11-02; 09:00; 18:00; Дневная смена"
        )
        return ConversationHandler.END
    raw = " ".join(context.args)
    p = [x.strip() for x in raw.split(";")]
    if len(p) < 4 or not p[0].isdigit():
        await update.message.reply_text("Проверьте формат команды.")
        return ConversationHandler.END
    uid, day, start_time, end_time = int(p[0]), p[1], p[2], p[3]
    note = p[4] if len(p) > 4 else ""
    try:
        datetime.strptime(day, "%Y-%m-%d")
        datetime.strptime(start_time, "%H:%M")
        datetime.strptime(end_time, "%H:%M")
    except ValueError:
        await update.message.reply_text("Дата должна быть ГГГГ-ММ-ДД, время — ЧЧ:ММ.")
        return ConversationHandler.END
    with db() as con:
        con.execute(
            "INSERT INTO schedules(user_id, shift_date, start_time, end_time, note) VALUES (?, ?, ?, ?, ?)",
            (uid, day, start_time, end_time, note)
        )
    await update.message.reply_text("✅ График сохранён.")


async def my_schedule(update: Update, context: ContextTypes.DEFAULT_TYPE):
    with db() as con:
        rows = con.execute(
            "SELECT shift_date, start_time, end_time, note FROM schedules WHERE user_id=? AND shift_date>=? ORDER BY shift_date LIMIT 14",
            (update.effective_user.id, now_local().date().isoformat())
        ).fetchall()
    if not rows:
        await update.message.reply_text("График пока не установлен.")
        return
    lines = ["🕒 Ваш график:"]
    for r in rows:
        lines.append(f"• {r['shift_date']}: {r['start_time']}–{r['end_time']} {r['note'] or ''}")
    await update.message.reply_text("\n".join(lines))


async def help_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "Команды:\n"
        "/start — главное меню\n/myid — ваш Telegram ID\n"
        "/register Имя Фамилия; Отдел; Должность — регистрация\n"
        "/in — отметить приход (геолокация + фото)\n"
        "/out — отметить уход (геолокация + фото)\n"
        "/tasks — мои задания\n/done НОМЕР — завершить задание\n"
        "/report — отчёт руководства\n/employees — список сотрудников\n"
        "/schedule ID; ДАТА; НАЧАЛО; КОНЕЦ; ПРИМЕЧАНИЕ — назначить смену"
    )


async def text_router(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text
    uid = update.effective_user.id
    routes = {
        "🟢 Отметить приход": clock_in_cmd,
        "🔴 Отметить уход": clock_out_cmd,
        "📋 Мои задания": my_tasks,
        "🕒 Мой график": my_schedule,
        "🆔 Мой ID": myid,
        "❓ Помощь": help_cmd,
        "👥 Сотрудники": employees,
        "📊 Отчёт": report,
        "➕ Создать задание": create_task,
        "🗓 Установить график": set_schedule,
    }
    handler = routes.get(text)
    if handler:
        if handler in (clock_in_cmd, clock_out_cmd, create_task):
            await handler(update, context)
        else:
            await handler(update, context)


def main():
    if not TOKEN:
        raise RuntimeError("Не задан BOT_TOKEN в переменных окружения.")
    init_db()
    app = Application.builder().token(TOKEN).build()

    attendance_conv = ConversationHandler(
        entry_points=[
            CommandHandler("in", clock_in_cmd),
            CommandHandler("out", clock_out_cmd),
            MessageHandler(filters.Regex("^🟢 Отметить приход$"), clock_in_cmd),
            MessageHandler(filters.Regex("^🔴 Отметить уход$"), clock_out_cmd),
        ],
        states={
            WAIT_LOCATION: [MessageHandler(filters.LOCATION | filters.TEXT, location_received)],
            WAIT_PHOTO: [MessageHandler(filters.PHOTO, photo_received)],
        },
        fallbacks=[CommandHandler("cancel", cancel), MessageHandler(filters.Regex("^Отмена$"), cancel)],
        allow_reentry=True
    )
    task_conv = ConversationHandler(
        entry_points=[
            CommandHandler("newtask", create_task),
            MessageHandler(filters.Regex("^➕ Создать задание$"), create_task),
        ],
        states={
            WAIT_TASK_EMPLOYEE: [CallbackQueryHandler(choose_task_employee, pattern=r"^taskuser:\d+$")],
            WAIT_TASK: [MessageHandler(filters.TEXT & ~filters.COMMAND, save_task)],
        },
        fallbacks=[CommandHandler("cancel", cancel)],
        allow_reentry=True
    )

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("myid", myid))
    app.add_handler(CommandHandler("register", register))
    app.add_handler(CommandHandler("employees", employees))
    app.add_handler(CommandHandler("tasks", my_tasks))
    app.add_handler(CommandHandler("done", done))
    app.add_handler(CommandHandler("report", report))
    app.add_handler(CommandHandler("schedule", set_schedule))
    app.add_handler(CommandHandler("myschedule", my_schedule))
    app.add_handler(CommandHandler("help", help_cmd))
    app.add_handler(attendance_conv)
    app.add_handler(task_conv)
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, text_router))

    log.info("OMAR KHAYAM bot starting")
    app.run_polling(drop_pending_updates=True)


if __name__ == "__main__":
    main()
